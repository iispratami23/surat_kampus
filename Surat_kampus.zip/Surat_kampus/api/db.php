<?php
// db.php: koneksi database, sesi, dan fungsi bantu untuk semua endpoint
require __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]);
session_start();

function out($data, $code = 200) { http_response_code($code); echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }
function fail($msg, $code = 400) { out(['error' => $msg], $code); }
function pdo() {
  static $p = null;
  if ($p === null) {
    try {
      $p = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
      ]);
    } catch (Throwable $e) { error_log($e); fail('DB_CONNECT', 500); }
  }
  return $p;
}
function body() { $j = json_decode(file_get_contents('php://input'), true); return is_array($j) ? $j : []; }
// Semua permintaan yang mengubah data harus POST + header khusus (perlindungan CSRF sederhana)
function only_post() {
  if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('METHOD', 405);
  if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'fetch') fail('CSRF', 403);
}
function login_required() { if (empty($_SESSION['uid'])) fail('UNAUTHORIZED', 401); }
function user_row($u) { return ['id' => (int)$u['id'], 'nama' => $u['nama'], 'jabatan' => $u['jabatan'], 'email' => $u['email'], 'role' => $u['role']]; }
function cut($s, $n) { // potong teks maksimal $n karakter (aman untuk huruf UTF-8, dengan atau tanpa ekstensi mbstring)
  $s = trim((string)$s);
  if (function_exists('mb_substr')) return mb_substr($s, 0, $n);
  return preg_match('/^.{0,' . (int)$n . '}/us', $s, $m) ? $m[0] : substr($s, 0, $n);
}

set_exception_handler(function ($e) { error_log($e); out(['error' => 'SERVER'], 500); });
