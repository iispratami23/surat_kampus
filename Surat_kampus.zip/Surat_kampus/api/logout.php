<?php
require __DIR__ . '/db.php';
only_post();
$_SESSION = [];
session_destroy();
out(['ok' => true]);
