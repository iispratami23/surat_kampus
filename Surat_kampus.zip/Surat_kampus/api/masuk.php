<?php
// Login yang mewajibkan kode keamanan. Isi sama dengan login.php, ditambah pemeriksaan kode di awal.
require __DIR__ . '/kode_lib.php'; // sudah memuat db.php
only_post();
$d = body();
if (!kode_ok($d['kode'] ?? '')) { usleep(300000); fail('CAPTCHA_INVALID', 400); }
$email = strtolower(cut($d['email'] ?? '', 150)); $pw = (string)($d['password'] ?? '');
$st = pdo()->prepare('SELECT * FROM users WHERE email = ?'); $st->execute([$email]);
$u = $st->fetch();
if (!$u || !password_verify($pw, $u['password_hash'])) { usleep(400000); fail('INVALID_CREDENTIALS', 401); }
session_regenerate_id(true);
$_SESSION['uid'] = (int)$u['id'];
out(['user' => user_row($u)]);
