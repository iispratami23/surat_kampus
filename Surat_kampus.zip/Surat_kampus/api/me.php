<?php
require __DIR__ . '/db.php';
if (empty($_SESSION['uid'])) out(['user' => null]);
$st = pdo()->prepare('SELECT * FROM users WHERE id = ?'); $st->execute([$_SESSION['uid']]);
$u = $st->fetch();
out(['user' => $u ? user_row($u) : null]);
