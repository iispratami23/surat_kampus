<?php
require __DIR__ . '/db.php';
only_post();
$d = body();
$nama = cut($d['nama'] ?? '', 100); $jabatan = cut($d['jabatan'] ?? '', 100);
$email = strtolower(cut($d['email'] ?? '', 150)); $pw = (string)($d['password'] ?? '');
if ($nama === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pw) < 6) fail('INVALID_INPUT');

$db = pdo();
$db->beginTransaction();
$jumlah = (int)$db->query('SELECT COUNT(*) FROM users')->fetchColumn();
try {
  $db->prepare('INSERT INTO users (nama, jabatan, email, password_hash, role) VALUES (?,?,?,?,?)')
     ->execute([$nama, $jabatan, $email, password_hash($pw, PASSWORD_DEFAULT), $jumlah === 0 ? 'admin' : 'staf']); // akun pertama = admin
} catch (PDOException $e) {
  $db->rollBack();
  if ($e->getCode() === '23000') fail('EMAIL_EXISTS', 409);
  throw $e;
}
$id = (int)$db->lastInsertId();
$db->commit();
session_regenerate_id(true);
$_SESSION['uid'] = $id;
$st = $db->prepare('SELECT * FROM users WHERE id = ?'); $st->execute([$id]);
out(['user' => user_row($st->fetch())]);
