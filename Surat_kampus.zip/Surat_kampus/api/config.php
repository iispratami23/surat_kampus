<?php
// Isi sesuai database di hosting (cPanel > MySQL Databases)
const DB_HOST = 'localhost';
const DB_NAME = 'nama_database';
const DB_USER = 'user_database';
const DB_PASS = 'kata_sandi_database';
