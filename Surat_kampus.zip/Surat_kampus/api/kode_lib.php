<?php
// kode_lib.php: soal keamanan acak (CAPTCHA) yang dibuat dan diperiksa di sisi server.
// Jawaban hanya disimpan di sesi server, tidak pernah dikirim ke browser, berlaku sekali pakai.
require __DIR__ . '/db.php';

const KODE_BERLAKU = 300;     // detik
const KODE_MODE    = 'nomor'; // 'nomor' = nomor acak (angka) | 'soal' = soal acak (penjumlahan, dll.)
const KODE_DIGIT   = 5;       // jumlah angka pada mode 'nomor'

// Samakan bentuk jawaban: huruf kecil, spasi dibuang, angka "08" dianggap "8"
function kode_norm($s) {
  $s = strtolower(trim((string)$s));
  return preg_match('/^\d+$/', $s) ? (string)(int)$s : $s;
}

// Hasil: [teks soal, jawaban, petunjuk]
function kode_soal() {
  $kata  = ['KAMPUS', 'SURAT', 'DISPOSISI', 'ARSIP', 'MAHASISWA', 'DOSEN', 'LAPORAN', 'AGENDA', 'UNIVERSITAS', 'SEKRETARIAT'];
  $angka = [1 => 'satu', 2 => 'dua', 3 => 'tiga', 4 => 'empat', 5 => 'lima', 6 => 'enam', 7 => 'tujuh', 8 => 'delapan', 9 => 'sembilan', 10 => 'sepuluh'];
  $hari  = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
  $nomor = 'Jawab dengan angka';
  $last = $_SESSION['kode_jenis'] ?? 0;
  do { $j = random_int(1, 10); } while ($j === $last); // tidak pernah jenis yang sama dua kali berturut-turut
  $_SESSION['kode_jenis'] = $j;
  switch ($j) {
    case 1: $a = random_int(3, 19); $b = random_int(3, 19); return ["Berapa $a ditambah $b ?", (string)($a + $b), $nomor];
    case 2: $a = random_int(10, 30); $b = random_int(2, $a - 3); return ["Berapa $a dikurangi $b ?", (string)($a - $b), $nomor];
    case 3: $a = random_int(2, 9); $b = random_int(2, 9); return ["Berapa $a dikali $b ?", (string)($a * $b), $nomor];
    case 4: case 5:
      $n = [];
      while (count($n) < 4) { $x = random_int(1, 60); if (!in_array($x, $n, true)) $n[] = $x; }
      $besar = ($j === 4);
      return ['Mana angka yang paling ' . ($besar ? 'BESAR' : 'KECIL') . ' di antara: ' . implode(', ', $n) . ' ?', (string)($besar ? max($n) : min($n)), $nomor];
    case 6: $k = $kata[random_int(0, count($kata) - 1)]; $i = random_int(1, strlen($k)); return ["Huruf ke-$i dari kata $k adalah ?", strtolower($k[$i - 1]), 'Jawab dengan satu huruf'];
    case 7: $n = random_int(1, 10); return ['Tulis dengan angka: ' . $angka[$n], (string)$n, $nomor];
    case 8: $s = random_int(1, 9); $d = random_int(2, 5); return ['Lanjutkan deret ini: ' . implode(', ', [$s, $s + $d, $s + 2 * $d, $s + 3 * $d]) . ', ... ?', (string)($s + 4 * $d), $nomor];
    case 9: $i = random_int(0, 6); $sesudah = (bool)random_int(0, 1); return ['Hari ' . ($sesudah ? 'sesudah' : 'sebelum') . ' ' . ucfirst($hari[$i]) . ' adalah ?', $hari[($i + ($sesudah ? 1 : 6)) % 7], 'Jawab dengan nama hari'];
    default: $k = $kata[random_int(0, count($kata) - 1)]; return ["Ada berapa huruf pada kata $k ?", (string)strlen($k), $nomor];
  }
}

// Gambar angka bergaya 7-segmen (tebal dan jelas), sedikit miring dan diberi gangguan ringan
function kode_png($digits) {
  $w = 190; $h = 70;
  $im = imagecreatetruecolor($w, $h);
  imagefill($im, 0, 0, imagecolorallocate($im, 246, 247, 249));
  for ($i = 0; $i < 150; $i++) imagesetpixel($im, random_int(0, $w - 1), random_int(0, $h - 1), imagecolorallocate($im, random_int(175, 220), random_int(175, 220), random_int(175, 220)));
  for ($i = 0; $i < 3; $i++) imageline($im, random_int(0, $w), random_int(0, $h), random_int(0, $w), random_int(0, $h), imagecolorallocate($im, random_int(180, 210), random_int(180, 210), random_int(180, 210)));
  $seg = ['0' => 'abcdef', '1' => 'bc', '2' => 'abdeg', '3' => 'abcdg', '4' => 'bcfg', '5' => 'acdfg', '6' => 'acdefg', '7' => 'abc', '8' => 'abcdefg', '9' => 'abcdfg'];
  $n = strlen($digits); $slot = ($w - 20) / $n; $hw = 10; $hh = 22;
  imagesetthickness($im, 5);
  for ($i = 0; $i < $n; $i++) {
    $cx = 10 + $slot * $i + $slot / 2; $cy = $h / 2 + random_int(-3, 3);
    $ang = deg2rad(random_int(-8, 8)); $shear = random_int(0, 12) / 100; $ox = $digits[$i] === '1' ? -$hw : 0; // angka 1 diletakkan di tengah kotaknya
    $col = imagecolorallocate($im, random_int(10, 60), random_int(30, 80), random_int(70, 125));
    $P = function ($x, $y) use ($cx, $cy, $ang, $shear, $ox) { // titik sudut: miring + geser
      $x += $ox + $y * $shear;
      return [(int)round($cx + $x * cos($ang) - $y * sin($ang)), (int)round($cy + $x * sin($ang) + $y * cos($ang))];
    };
    $A = $P(-$hw, -$hh); $B = $P($hw, -$hh); $ML = $P(-$hw, 0); $MR = $P($hw, 0); $D = $P(-$hw, $hh); $E = $P($hw, $hh);
    $garis = ['a' => [$A, $B], 'b' => [$B, $MR], 'c' => [$MR, $E], 'd' => [$D, $E], 'e' => [$ML, $D], 'f' => [$A, $ML], 'g' => [$ML, $MR]];
    foreach (str_split($seg[$digits[$i]]) as $k) imageline($im, $garis[$k][0][0], $garis[$k][0][1], $garis[$k][1][0], $garis[$k][1][1], $col);
  }
  imagesetthickness($im, 1);
  for ($i = 0; $i < 2; $i++) imageline($im, 0, random_int(8, $h - 8), $w, random_int(8, $h - 8), imagecolorallocate($im, 185, 192, 210));
  ob_start(); imagepng($im); $png = ob_get_clean(); imagedestroy($im);
  return $png;
}

function kode_new() {
  if (KODE_MODE === 'soal') {
    $q = kode_soal();
    $_SESSION['kode'] = ['v' => kode_norm($q[1]), 't' => time(), 'm' => 'soal'];
    return ['type' => 'soal', 'soal' => $q[0], 'petunjuk' => $q[2]];
  }
  $d = '';
  for ($i = 0; $i < KODE_DIGIT; $i++) $d .= (string)random_int(0, 9);
  $_SESSION['kode'] = ['v' => $d, 't' => time(), 'm' => 'nomor'];
  if (function_exists('imagecreatetruecolor') && function_exists('imagepng')) // gambar: angkanya tidak ada di balasan
    return ['type' => 'image', 'image' => 'data:image/png;base64,' . base64_encode(kode_png($d))];
  return ['type' => 'canvas', 'nomor' => $d]; // tanpa GD: angka digambar di browser
}

// Periksa jawaban. Dihapus setelah dipakai (sekali pakai, benar atau salah) dan kedaluwarsa setelah 5 menit.
function kode_ok($input) {
  $c = $_SESSION['kode'] ?? null;
  unset($_SESSION['kode']);
  if (!is_array($c) || time() - $c['t'] > KODE_BERLAKU) return false;
  $a = ($c['m'] ?? 'soal') === 'nomor' ? preg_replace('/\s+/', '', trim((string)$input)) : kode_norm($input);
  return hash_equals($c['v'], $a);
}
