<?php
// Meminta kode keamanan baru. Dipanggil halaman login.
require __DIR__ . '/kode_lib.php';
if ($_SERVER['REQUEST_METHOD'] !== 'GET') fail('METHOD', 405);
header('Cache-Control: no-store');
out(kode_new());
