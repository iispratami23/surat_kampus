<?php
// GET  -> semua surat beserta disposisinya (dilihat semua pengguna yang login)
// POST -> simpan surat (baru atau perubahan, dikenali dari nomor surat) beserta riwayat disposisinya
require __DIR__ . '/db.php';
login_required();
$db = pdo();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  $rows = $db->query('SELECT id, nomor, jenis, perihal, pihak, keterangan, tanggal, status, lampiran, isi FROM surat ORDER BY id DESC')->fetchAll();
  $disp = [];
  foreach ($db->query('SELECT surat_id, tujuan, instruksi, batas_waktu, catatan, tanggal, oleh FROM disposisi ORDER BY id DESC') as $x) {
    $disp[$x['surat_id']][] = ['ke' => $x['tujuan'], 'instruksi' => $x['instruksi'], 'batas' => $x['batas_waktu'] ?? '', 'catatan' => $x['catatan'], 't' => $x['tanggal'], 'oleh' => $x['oleh']];
  }
  $data = array_map(function ($r) use ($disp) {
    $o = ['n' => $r['nomor'], 'j' => $r['jenis'], 'p' => $r['perihal'], 'a' => $r['pihak'], 's' => $r['keterangan'], 't' => $r['tanggal'], 'st' => $r['status']];
    if ($r['isi'] !== null) $o['isi'] = $r['isi'];
    if ($r['lampiran'] !== null) $o['lampiran'] = $r['lampiran'];
    if (!empty($disp[$r['id']])) $o['disp'] = $disp[$r['id']];
    return $o;
  }, $rows);
  out(['data' => $data]);
}

only_post();
$d = body();
$n = cut($d['n'] ?? '', 100); $j = $d['j'] ?? ''; $p = cut($d['p'] ?? '', 255); $a = cut($d['a'] ?? '', 150);
$s = cut($d['s'] ?? '', 255); $t = cut($d['t'] ?? '', 30); $st = $d['st'] ?? 'Diproses';
if ($n === '' || $p === '' || $a === '' || !in_array($j, ['masuk', 'keluar'], true)
    || !in_array($st, ['Perlu disposisi', 'Diproses', 'Terkirim', 'Diarsipkan'], true)) fail('INVALID_INPUT');
$isi = isset($d['isi']) ? (string)$d['isi'] : null;
$lampiran = isset($d['lampiran']) ? cut($d['lampiran'], 150) : null;

$db->beginTransaction();
$db->prepare('INSERT INTO surat (nomor, jenis, perihal, pihak, keterangan, tanggal, status, lampiran, isi, dibuat_oleh)
              VALUES (?,?,?,?,?,?,?,?,?,?)
              ON DUPLICATE KEY UPDATE jenis=VALUES(jenis), perihal=VALUES(perihal), pihak=VALUES(pihak), keterangan=VALUES(keterangan),
                tanggal=VALUES(tanggal), status=VALUES(status), lampiran=VALUES(lampiran), isi=VALUES(isi)')
   ->execute([$n, $j, $p, $a, $s, $t, $st, $lampiran, $isi, $_SESSION['uid']]);
$q = $db->prepare('SELECT id FROM surat WHERE nomor = ?'); $q->execute([$n]);
$id = (int)$q->fetchColumn();

// Riwayat disposisi diganti sesuai kiriman (urutan terlama -> terbaru agar id naik)
$db->prepare('DELETE FROM disposisi WHERE surat_id = ?')->execute([$id]);
$ins = $db->prepare('INSERT INTO disposisi (surat_id, tujuan, instruksi, batas_waktu, catatan, tanggal, oleh) VALUES (?,?,?,?,?,?,?)');
foreach (array_reverse(is_array($d['disp'] ?? null) ? $d['disp'] : []) as $x) {
  $batas = trim((string)($x['batas'] ?? ''));
  $ins->execute([$id, cut($x['ke'] ?? '', 100), cut($x['instruksi'] ?? '', 100),
    preg_match('/^\d{4}-\d{2}-\d{2}$/', $batas) ? $batas : null, cut($x['catatan'] ?? '', 255), cut($x['t'] ?? '', 30), cut($x['oleh'] ?? '', 100)]);
}
$db->commit();
out(['ok' => true]);
