// Code.gs: tempel di Google Sheets > Extensions > Apps Script, lalu Deploy sebagai Web app.
// Surat masuk dan keluar masuk otomatis ke dua sheet: "Surat Masuk" dan "Surat Keluar".
/** @OnlyCurrentDoc */

const KOLOM = ["Dicatat", "Nomor surat", "Perihal", "Pengirim / Penerima", "Keterangan",
               "Tanggal surat", "Status", "Disposisi terakhir", "Dicatat oleh"];

// Dipanggil otomatis oleh aplikasi (jangan dijalankan manual dari editor; untuk tes pakai uji())
function doPost(e) {
  if (!e || !e.postData) {
    return jawab({ ok: false, pesan: "Tidak ada data. Fungsi ini dipanggil oleh aplikasi, bukan dari editor." });
  }
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const d = JSON.parse(e.postData.contents);
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    (d.baris || [d]).forEach(function (r) { simpan(ss, r); });
    return jawab({ ok: true });
  } catch (err) {
    return jawab({ ok: false, pesan: String(err) });
  } finally {
    lock.releaseLock();
  }
}

function doGet() {
  return ContentService.createTextOutput("Web app aktif");
}

function jawab(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

// Nomor surat yang sama diperbarui (status, disposisi); nomor baru ditambahkan di baris bawah
function simpan(ss, r) {
  const nama = r.jenis === "masuk" ? "Surat Masuk" : "Surat Keluar";
  let sh = ss.getSheetByName(nama);
  if (!sh) {
    sh = ss.insertSheet(nama);
    sh.appendRow(KOLOM);
    sh.setFrozenRows(1);
    sh.getRange(1, 1, 1, KOLOM.length).setFontWeight("bold");
    sh.getRange("B:B").setNumberFormat("@");
  }
  const baris = [new Date(), String(r.nomor), r.perihal, r.pihak, r.ket,
                 r.tanggal, r.status, r.disposisi || "", r.oleh];
  const last = sh.getLastRow();
  const daftar = last > 1
    ? sh.getRange(2, 2, last - 1, 1).getValues().map(function (x) { return String(x[0]); })
    : [];
  const i = daftar.indexOf(String(r.nomor));
  if (i >= 0) sh.getRange(i + 2, 1, 1, KOLOM.length).setValues([baris]);
  else sh.appendRow(baris);
}

// Untuk tes: pilih fungsi "uji" di editor lalu klik Jalankan. Hapus baris UJI/001 setelahnya.
function uji() {
  simpan(SpreadsheetApp.getActiveSpreadsheet(), {
    jenis: "masuk", nomor: "UJI/001", perihal: "Tes koneksi", pihak: "Uji coba",
    ket: "Hapus baris ini", tanggal: "09 Nov 2026", status: "Diproses", disposisi: "", oleh: "Tes"
  });
}
