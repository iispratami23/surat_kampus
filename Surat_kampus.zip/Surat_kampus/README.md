# Manajemen Surat (versi database SQL)

Aplikasi web (HTML + CSS + JavaScript) dengan backend **PHP** dan database **MySQL/MariaDB**.
Semua akun dan surat disimpan di database server, jadi semua pengguna yang login melihat data yang sama
dari komputer atau browser mana pun.

## Kebutuhan hosting
PHP 7.4 atau lebih baru dengan ekstensi PDO MySQL (standar di cPanel), dan satu database MySQL/MariaDB. HTTPS disarankan.

## Cara memasang di hosting (cPanel)
1. **Buat database:** cPanel > *MySQL Databases*. Buat database, buat user, lalu tambahkan user ke database dengan *All Privileges*.
2. **Impor tabel:** cPanel > *phpMyAdmin* > pilih database tadi > tab *Import* > pilih `database.sql` > *Go*.
   Akan terbentuk tiga tabel: `users`, `surat`, `disposisi`.
3. **Isi koneksi:** buka `api/config.php`, ganti `DB_NAME`, `DB_USER`, `DB_PASS` (biasanya `DB_HOST` tetap `localhost`).
4. **Unggah file:** upload seluruh isi folder ini ke `public_html` (atau subfolder) lewat *File Manager* atau FTP.
5. **Buka** `https://domainanda/login.html`, lalu daftar. **Akun pertama otomatis menjadi admin.**

## Struktur database
| Tabel | Isi |
|---|---|
| `users` | nama, jabatan, email (unik), password_hash (bcrypt), role (admin/staf) |
| `surat` | nomor (unik), jenis (masuk/keluar), perihal, pihak, keterangan, tanggal, status, lampiran, isi, dibuat_oleh |
| `disposisi` | surat_id (relasi ke surat), tujuan, instruksi, batas_waktu, catatan, tanggal, oleh |

Relasi: satu akun mencatat banyak surat; satu surat punya banyak disposisi (dihapus otomatis bila suratnya dihapus).

## API (folder `api/`)
| File | Fungsi |
|---|---|
| `register.php`, `login.php`, `logout.php`, `me.php` | akun dan sesi (kata sandi di-hash dengan `password_hash`) |
| `surat.php` | GET: semua surat + disposisi. POST: simpan surat baru atau perubahan (dikenali dari nomor surat) |
| `db.php`, `config.php` | koneksi database dan fungsi bantu (`config.php` diblokir dari akses langsung lewat `.htaccess`) |

## Keamanan
- Kueri memakai prepared statement (aman dari SQL injection), kata sandi di-hash, sesi memakai cookie HttpOnly.
- Permintaan yang mengubah data wajib POST dengan header khusus (perlindungan CSRF sederhana).
- Ganti kata sandi database di `config.php` dengan yang kuat, dan jangan membagikan file itu.

## Yang masih tersimpan di browser (bukan di database)
Kop surat, pilihan tema, dan alamat Google Sheets. Ketiganya pengaturan per perangkat.

## Fitur lain
Cetak surat, pencarian, dan kiriman otomatis ke Google Sheets (`apps-script/Code.gs`) tetap berfungsi seperti sebelumnya.

## Tambahan: kode keamanan (CAPTCHA) nomor acak di halaman login
Semuanya FILE BARU; tidak ada file lama yang diubah: `masuk.html`, `js/kode.js`, `api/kode.php`, `api/kode_lib.php`, `api/masuk.php`, dan `.htaccess` (di folder utama).
- `.htaccess` membuat alamat `login.html` menampilkan `masuk.html` (halaman login dengan nomor acak 5 angka) dan mengalihkan `api/login.php`
  ke `api/masuk.php` yang memeriksa kode. File `login.html` dan `api/login.php` sendiri tidak disentuh.
- Nomor hanya ada di sesi server, berlaku sekali pakai, dan kedaluwarsa dalam 5 menit.
- Butuh Apache dengan modul rewrite aktif (bawaan Laragon dan cPanel). Bila tidak aktif, aplikasi berjalan seperti semula; buka `masuk.html` langsung untuk login dengan kode.
- Mau soal acak (penjumlahan, dll.) sebagai pengganti nomor? Ubah `KODE_MODE` di `api/kode_lib.php` menjadi `'soal'`.
