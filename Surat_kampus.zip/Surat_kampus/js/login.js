// login.js: logika halaman masuk
// Jika sudah login, langsung ke dashboard
DB_READY.then(() => {
  if (currentUser()) location.replace("dashboard.html");
  else if (window.DB_ERROR) setFormErr("login-form-error", errMsg(new Error(window.DB_ERROR)));
});

$("login-form").addEventListener("submit", async e => {
  e.preventDefault();
  const email = $("login-email").value, pw = $("login-password").value;
  const errs = { "login-email": validEmail(email) ? "" : "Masukkan email yang valid.", "login-password": pw ? "" : "Kata sandi wajib diisi." };
  setFormErr("login-form-error", ""); Object.keys(errs).forEach(k => setErr(k, errs[k]));
  if (Object.values(errs).some(Boolean)) return;
  try { setBusy($("login-btn"), true, "Masuk"); await loginUser(email, pw); location.href = "dashboard.html"; }
  catch (err) { setFormErr("login-form-error", errMsg(err)); }
  finally { setBusy($("login-btn"), false, "Masuk"); }
});

