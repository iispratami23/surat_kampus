// sheets.js: TAMBAHAN. Kirim surat otomatis ke Google Sheets + unduh Excel. Tidak mengubah kode lain.
(function () {
  const URL_KEY = "surat_sheet_url", Q_KEY = "surat_sheet_queue";
  const getUrl = () => store.getItem(URL_KEY) || "";
  const readQ = () => { try { return JSON.parse(store.getItem(Q_KEY)) || []; } catch (e) { return []; } };
  const later = (m) => setTimeout(() => toast(m), 2300); // setelah toast bawaan selesai

  const row = (r) => {
    const h = (r.disp || [])[0];
    return {
      jenis: r.j, nomor: r.n, perihal: r.p, pihak: r.a, ket: r.s, tanggal: r.t, status: r.st,
      disposisi: h ? h.ke + " - " + h.instruksi + (h.catatan ? " (" + h.catatan + ")" : "") : "",
      oleh: (me && me.nama) || "",
    };
  };

  // Kirim antrean; jika gagal (offline), antrean disimpan dan dicoba lagi saat halaman dibuka
  async function flush() {
    const url = getUrl(), q = readQ();
    if (!url || !q.length) return true;
    try {
      await fetch(url, { method: "POST", mode: "no-cors", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify({ baris: q }) });
      store.setItem(Q_KEY, "[]");
      return true;
    } catch (e) { return false; }
  }
  function kirim(letters) {
    if (!getUrl()) return;
    store.setItem(Q_KEY, JSON.stringify(readQ().concat(letters.map(row))));
    flush().then((ok) => later(ok ? "Tersimpan ke Google Sheets." : "Belum terkirim ke Google Sheets, akan dicoba lagi."));
  }
  const currentLetter = () => {
    const p = document.querySelector("#dlg p");
    return p ? LET.find((x) => x.n === p.textContent.split(" · ")[0]) : null;
  };

  // ----- Otomatis: surat baru, perubahan status, disposisi -----
  document.addEventListener("submit", (e) => {
    if (e.target.id === "addf") kirim([LET[0]]);
    if (e.target.id === "dispf") { const r = currentLetter(); if (r) kirim([r]); }
  });
  document.addEventListener("change", (e) => {
    if (e.target.id === "dstat") { const r = currentLetter(); if (r) kirim([r]); }
  });

  // ----- Excel (.xlsx) -----
  const HEAD = ["Nomor surat", "Perihal", "Pengirim / Penerima", "Keterangan", "Tanggal surat", "Status", "Disposisi terakhir"];
  const table = (j) => [HEAD].concat(LET.filter((x) => x.j === j).map((r) => {
    const o = row(r); return [o.nomor, o.perihal, o.pihak, o.ket, o.tanggal, o.status, o.disposisi];
  }));
  const loadXlsx = () => new Promise((ok, no) => {
    if (window.XLSX) return ok();
    const s = document.createElement("script");
    s.src = "https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js";
    s.onload = ok; s.onerror = no; document.head.appendChild(s);
  });
  async function excel() {
    const tgl = new Date().toISOString().slice(0, 10);
    try {
      await loadXlsx();
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(table("masuk")), "Surat Masuk");
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(table("keluar")), "Surat Keluar");
      XLSX.writeFile(wb, "surat-" + tgl + ".xlsx");
    } catch (err) { // cadangan tanpa internet: CSV yang bisa dibuka di Excel
      const csv = "\ufeffsep=;\n" + table("masuk").concat([[]], table("keluar"))
        .map((r) => r.map((c) => '"' + String(c).replace(/"/g, '""') + '"').join(";")).join("\n");
      const a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
      a.download = "surat-" + tgl + ".csv"; a.click();
    }
  }
  // Tombol "Ekspor" di dashboard: jalankan unduh Excel, bukan toast
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-toast]");
    if (b && /Ekspor/.test(b.dataset.toast)) { e.stopImmediatePropagation(); excel(); }
  }, true);

  // ----- Pengaturan: kotak koneksi Google Sheets -----
  function box() {
    const m = document.getElementById("main");
    if (!m || !m.querySelector("#theme") || m.querySelector("#sheetbox")) return;
    m.insertAdjacentHTML("beforeend", `<div class="box" id="sheetbox"><div class="bh"><h3>Google Sheets dan Excel</h3></div>
      <p style="font-size:13px;color:var(--muted);margin:0 0 12px">Surat masuk dan keluar dikirim otomatis ke Google Sheets setiap kali ditambah atau diubah.</p>
      <div class="field"><label for="sheeturl">URL Web App (Apps Script)</label>
        <div class="input-box"><input id="sheeturl" placeholder="https://script.google.com/macros/s/.../exec" value="${esc(getUrl())}"></div></div>
      <button class="bt" id="sheetsave">Simpan</button>
      <button class="bs" id="sheetall">Kirim semua surat sekarang</button>
      <button class="bs" id="sheetxls">Unduh Excel (.xlsx)</button></div>`);
  }
  document.addEventListener("click", (e) => {
    const id = (e.target.closest("button") || {}).id;
    if (id === "sheetsave") {
      const v = document.getElementById("sheeturl").value.trim();
      if (v && !/^https:\/\/script\.google\.com\/macros\/s\/[^\s]+\/exec$/.test(v)) return toast("URL harus berakhiran /exec dari Apps Script.");
      v ? store.setItem(URL_KEY, v) : store.removeItem(URL_KEY);
      toast(v ? "Google Sheets terhubung." : "Koneksi Google Sheets dihapus.");
      flush();
    }
    if (id === "sheetall") { if (!getUrl()) return toast("Isi dan simpan URL Web App dulu."); if (!LET.length) return toast("Belum ada surat."); kirim(LET); }
    if (id === "sheetxls") excel();
  });
  const app = document.getElementById("app");
  if (app) new MutationObserver(box).observe(app, { childList: true, subtree: true });
  box();
  flush();
})();
