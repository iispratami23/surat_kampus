// kode.js: TAMBAHAN untuk halaman login. Menampilkan kode keamanan (nomor acak) dari server.
// Tidak mengubah login.js maupun core.js; hanya menambah kolom dan menyertakan jawaban saat login.
(function () {
  const form = document.getElementById("login-form"), btn = document.getElementById("login-btn");
  if (!form || !btn) return;
  btn.insertAdjacentHTML("beforebegin", `<div class="field"><label for="login-captcha" id="cap-label">Kode keamanan</label>
    <div id="cap-view" style="border:1px solid var(--border);border-radius:10px;background:#f6f7f9;color:#111;padding:8px 12px;text-align:center;min-height:78px;display:flex;flex-direction:column;justify-content:center;align-items:center;gap:4px">Memuat...</div>
    <div style="text-align:right;margin:4px 0 8px"><button type="button" class="toggle" id="cap-refresh" aria-label="Ganti kode">↻ Ganti kode</button></div>
    <div class="input-box"><input id="login-captcha" autocomplete="off" inputmode="numeric" placeholder="Ketik nomor di atas" maxlength="20"></div>
    <div class="error" id="err-login-captcha"></div></div>`);

  const acak = (a, b) => a + Math.random() * (b - a);
  function gambar(nomor) { // mode tanpa GD: angka digambar di canvas dengan sedikit gangguan
    const c = document.createElement("canvas"); c.width = 190; c.height = 64; c.style.cssText = "display:block;max-width:100%;height:64px";
    const x = c.getContext("2d");
    x.fillStyle = "#f6f7f9"; x.fillRect(0, 0, 190, 64);
    for (let i = 0; i < 140; i++) { x.fillStyle = "rgb(" + [0, 0, 0].map(() => acak(175, 220) | 0).join(",") + ")"; x.fillRect(acak(0, 190), acak(0, 64), 1, 1); }
    x.font = "bold 42px Arial, sans-serif"; x.textBaseline = "middle";
    [...nomor].forEach((d, i) => {
      x.save(); x.translate(26 + i * 31, 32 + acak(-4, 4)); x.rotate(acak(-0.2, 0.2));
      x.fillStyle = "rgb(" + (acak(10, 60) | 0) + "," + (acak(30, 80) | 0) + "," + (acak(70, 125) | 0) + ")"; x.fillText(d, -12, 0); x.restore();
    });
    x.strokeStyle = "rgb(150,160,185)"; x.beginPath(); x.moveTo(0, acak(10, 54)); x.lineTo(190, acak(10, 54)); x.stroke();
    return c;
  }

  async function muat() {
    const v = document.getElementById("cap-view");
    document.getElementById("login-captcha").value = "";
    v.textContent = "Memuat...";
    try {
      const j = await api("kode.php");
      v.textContent = "";
      if (j.type === "image") { const im = new Image(); im.alt = "Kode keamanan"; im.style.cssText = "display:block;max-width:100%;height:64px"; im.src = j.image; v.appendChild(im); }
      else if (j.type === "canvas") v.appendChild(gambar(j.nomor));
      else {
        const q = document.createElement("div"); q.textContent = j.soal; q.style.cssText = "font-size:20px;font-weight:700;line-height:1.35";
        const h = document.createElement("div"); h.textContent = j.petunjuk + " (huruf besar atau kecil bebas)"; h.style.cssText = "font-size:12px;color:#555";
        v.appendChild(q); v.appendChild(h);
      }
      const soal = j.type === "soal";
      document.getElementById("cap-label").textContent = soal ? "Soal keamanan" : "Kode keamanan";
      document.getElementById("login-captcha").placeholder = soal ? "Ketik jawabanmu" : "Ketik nomor di atas";
    } catch (e) { v.textContent = "Gagal memuat kode. Klik Ganti kode."; }
  }
  document.getElementById("cap-refresh").addEventListener("click", muat);

  // Sertakan kode saat login; bila gagal, kode diganti baru
  let kodeSalah = false;
  loginUser = async function (email, pw) {
    try {
      CURRENT = (await api("masuk.php", { email: email, password: pw, kode: document.getElementById("login-captcha").value })).user;
    } catch (e) { kodeSalah = e.message === "CAPTCHA_INVALID"; muat(); throw e; }
  };
  // Pesan khusus bila kodenya yang salah
  const pesanAsli = setFormErr;
  setFormErr = function (id, msg) {
    if (msg && kodeSalah) { msg = "Kode keamanan salah atau kedaluwarsa. Silakan coba lagi."; kodeSalah = false; }
    pesanAsli(id, msg);
  };
  // Kolom kode tidak boleh kosong
  document.addEventListener("submit", function (e) {
    if (e.target.id !== "login-form") return;
    const ada = document.getElementById("login-captcha").value.trim() !== "";
    setErr("login-captcha", ada ? "" : "Isi kode keamanan terlebih dahulu.");
    if (!ada) { e.stopImmediatePropagation(); e.preventDefault(); }
  }, true);
  muat();
})();
