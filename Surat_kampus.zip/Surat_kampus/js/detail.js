// detail.js: TAMBAHAN. Detail surat + form disposisi. Tidak mengubah kode lain.
// Klik baris tabel mana pun -> membuka detail surat (menggantikan toast ringkasan).
(function () {
  const TUJUAN = ["Divisi Keuangan", "Divisi Sumber Daya Manusia", "Divisi Operasional", "Divisi Hukum", "Sekretariat Direksi"];
  const INSTR = ["Untuk diproses", "Untuk diketahui", "Segera tindak lanjut", "Untuk dibalas"];
  const STAT = ["Perlu disposisi", "Diproses", "Terkirim", "Diarsipkan"];
  const dlg = document.getElementById("dlg");
  let cur = null;
  const opt = (list, sel) => list.map(x => `<option${x === sel ? " selected" : ""}>${esc(x)}</option>`).join("");
  const today = () => new Date().toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });

  function show(n) {
    const r = LET.find(x => x.n === n);
    if (!r) return;
    cur = n;
    const hist = r.disp || [];
    dlg.style.width = "min(520px,94vw)";
    dlg.innerHTML = `
      <h3 style="margin:0;color:var(--navy)">${esc(r.p)}</h3>
      <p style="margin:4px 0 14px;font-size:12px;color:var(--muted)">${esc(r.n)} · ${r.j === "masuk" ? "Surat masuk" : "Surat keluar"} · ${esc(r.t)}</p>
      <div class="field"><label>${r.j === "masuk" ? "Pengirim" : "Penerima"}</label>
        <div style="font-size:14px">${esc(r.a)}<small style="display:block;color:var(--muted)">${esc(r.s)}</small></div></div>
      <div class="field"><label for="dstat">Status</label><select id="dstat" style="width:100%">${opt(STAT, r.st)}</select></div>
      <div class="field"><label>Riwayat disposisi</label>
        ${hist.length ? hist.map(h => `<div class="li" style="cursor:default"><div style="flex:1"><b>${esc(h.ke)}</b> · ${esc(h.instruksi)}<small>${esc(h.catatan || "Tanpa catatan")} · batas ${esc(h.batas)}</small></div><small>${esc(h.t)}<br>${esc(h.oleh)}</small></div>`).join("")
          : '<p style="margin:0;font-size:13px;color:var(--muted)">Belum ada disposisi.</p>'}
      </div>
      <form id="dispf">
        <label>Buat disposisi</label>
        <div class="field"><select id="dke" style="width:100%">${opt(TUJUAN)}</select></div>
        <div class="field"><select id="din" style="width:100%">${opt(INSTR)}</select></div>
        <div class="field"><div class="input-box"><input type="date" id="dbt" required></div></div>
        <div class="field"><div class="input-box"><input id="dca" placeholder="Catatan (opsional)"></div></div>
        <button class="bt" style="width:100%">Kirim disposisi</button>
      </form>
      <button type="button" class="bs" id="dprint" style="width:100%;margin-top:10px">Cetak surat</button>
      <button type="button" class="bs" id="dclose" style="width:100%;margin-top:8px">Tutup</button>`;
    if (!dlg.open) dlg.showModal();
  }

  // Capture: berjalan sebelum listener lama, lalu menghentikannya untuk baris tabel
  document.addEventListener("click", e => {
    const row = e.target.closest("[data-open]");
    if (!row) return;
    e.stopImmediatePropagation();
    show(row.dataset.open);
  }, true);

  dlg.addEventListener("click", e => {
    if (e.target.closest("#dclose")) dlg.close();
    if (e.target.closest("#dprint")) location.href = "cetak.html?n=" + encodeURIComponent(cur);
  });
  dlg.addEventListener("close", () => { dlg.style.width = ""; });

  dlg.addEventListener("change", e => {
    if (e.target.id !== "dstat") return;
    const r = LET.find(x => x.n === cur);
    r.st = e.target.value; saveLet(); draw(); show(cur); toast("Status diperbarui.");
  });

  dlg.addEventListener("submit", e => {
    if (e.target.id !== "dispf") return;
    e.preventDefault();
    const r = LET.find(x => x.n === cur);
    (r.disp = r.disp || []).unshift({
      ke: document.getElementById("dke").value,
      instruksi: document.getElementById("din").value,
      batas: document.getElementById("dbt").value,
      catatan: document.getElementById("dca").value.trim(),
      t: today(), oleh: me.nama,
    });
    if (r.st === "Perlu disposisi") r.st = "Diproses";
    saveLet(); draw(); show(cur); toast("Disposisi terkirim.");
  });
})();
