// search.js: TAMBAHAN. Pencarian surat. Dipakai di semua halaman:
// ketik di kolom cari atas -> daftar surat yang cocok muncul, Enter -> halaman Pencarian lengkap.
(function () {
  const norm = (s) => String(s == null ? "" : s).toLowerCase();
  const words = (q) => norm(q).split(/\s+/).filter(Boolean);
  // Teks yang dicari: nomor, perihal, pengirim/penerima, keterangan, tanggal, status, isi surat, catatan disposisi
  const hay = (l) => norm([l.n, l.p, l.a, l.s, l.t, l.st, l.isi, (l.disp || []).map((d) => [d.ke, d.instruksi, d.catatan].join(" ")).join(" ")].join(" "));
  // Semua kata yang diketik harus ada di surat (huruf besar/kecil diabaikan)
  window.cariWords = words;
  window.cariSurat = function (q, opt) {
    opt = opt || {};
    const ws = words(q);
    return LET.filter((l) => (!opt.j || opt.j === "all" || l.j === opt.j) && (!opt.st || opt.st === "all" || l.st === opt.st) && ws.every((w) => hay(l).includes(w)));
  };
  window.cariHighlight = function (text, ws) {
    if (!ws.length) return esc(text);
    const re = new RegExp("(" + ws.map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|") + ")", "gi");
    return String(text).split(re).map((p, i) => (i % 2 ? "<mark>" + esc(p) + "</mark>" : esc(p))).join("");
  };

  const st = document.createElement("style");
  st.textContent = `#qdrop{background:var(--card);border:1px solid var(--border);border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.18);overflow:hidden;font-size:13px;color:var(--text);text-align:left}
.qi{padding:10px 12px;border-bottom:1px solid var(--border);cursor:pointer}.qi:hover{background:var(--bg)}.qi small{display:block;color:var(--muted)}
.qe,.qa{display:block;padding:10px 12px;color:var(--muted);text-decoration:none}.qa{color:var(--acc);font-weight:600}.qa:hover{background:var(--bg)}
mark{background:color-mix(in srgb,var(--amber) 35%,transparent);color:inherit;border-radius:2px;padding:0 1px}`;
  document.head.appendChild(st);

  let box = null;
  const hide = () => { if (box) box.style.display = "none"; };
  function show(q) {
    const ws = words(q), inp = document.getElementById("q");
    if (!ws.length || !inp || (typeof S !== "undefined" && S.v === "cari")) return hide();
    if (!box) { box = document.createElement("div"); box.id = "qdrop"; document.body.appendChild(box); }
    const res = window.cariSurat(q), r = inp.getBoundingClientRect();
    box.style.cssText = "display:block;position:fixed;z-index:20;left:" + r.left + "px;top:" + (r.bottom + 6) + "px;width:" + Math.max(r.width, 320) + "px";
    box.innerHTML = (res.length ? res.slice(0, 6).map((l) => `<div class="qi" data-qopen="${esc(l.n)}"><b>${cariHighlight(l.n, ws)}</b> · ${l.j === "masuk" ? "Surat masuk" : "Surat keluar"}<div>${cariHighlight(l.p, ws)}</div><small>${cariHighlight(l.a, ws)} · ${esc(l.t)} · ${esc(l.st)}</small></div>`).join("")
      : '<div class="qe">Tidak ada surat yang cocok.</div>') + `<a class="qa" href="cari.html?q=${encodeURIComponent(q.trim())}">Lihat semua hasil (${res.length})</a>`;
  }
  document.addEventListener("input", (e) => { if (e.target.id === "q") show(e.target.value); });
  document.addEventListener("focusin", (e) => { if (e.target.id === "q" && e.target.value) show(e.target.value); });
  document.addEventListener("keydown", (e) => {
    if (e.target.id !== "q") return;
    if (e.key === "Enter") location.href = "cari.html" + (e.target.value.trim() ? "?q=" + encodeURIComponent(e.target.value.trim()) : "");
    if (e.key === "Escape") hide();
  });
  document.addEventListener("click", (e) => {
    const it = e.target.closest("[data-qopen]");
    if (it) { // buka detail surat lewat mekanisme klik baris yang sudah ada
      const n = it.dataset.qopen; hide();
      const t = document.createElement("span"); t.dataset.open = n; document.body.appendChild(t); t.click(); t.remove();
    } else if (!e.target.closest("#qdrop,#q")) hide();
  });
  window.addEventListener("resize", hide);
})();
