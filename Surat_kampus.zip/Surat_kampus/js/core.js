// core.js: penyimpanan, akun, data surat, dan helper bersama
const store = (function () {
  try { localStorage.setItem("__t", "1"); localStorage.removeItem("__t"); return localStorage; }
  catch (e) {
    const m = {};
    return { getItem: k => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: k => { delete m[k]; } };
  }
})();
const $ = id => document.getElementById(id);

// ===== Server: PHP + MySQL (lihat folder api/) =====
const API = "api/";
async function api(path, body) {
  let r;
  try {
    r = await fetch(API + path, { method: body ? "POST" : "GET", credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-Requested-With": "fetch" }, body: body ? JSON.stringify(body) : undefined });
  } catch (e) { throw new Error("NETWORK"); }
  let j = null; try { j = await r.json(); } catch (e) {}
  if (j === null) throw new Error("NO_API"); // balasan bukan JSON: folder api belum diunggah, atau PHP tidak berjalan
  if (!r.ok) throw new Error(j.error || "SERVER");
  return j;
}
let CURRENT = null; // akun yang sedang login (dari sesi di server)
const currentUser = () => CURRENT;
async function registerUser(d) { CURRENT = (await api("register.php", d)).user; }
async function loginUser(email, pw) { CURRENT = (await api("login.php", { email: email, password: pw })).user; }
async function logoutUser() { try { await api("logout.php", {}); } catch (e) {} CURRENT = null; }
const errMsg = e => ({ EMAIL_EXISTS: "Email sudah terdaftar. Silakan masuk.", INVALID_CREDENTIALS: "Email atau kata sandi salah.",
  NETWORK: "Tidak dapat terhubung ke server. Buka lewat alamat website atau localhost, bukan dengan klik dua kali file.",
  NO_API: "Server tidak membalas dengan benar. Pastikan folder api sudah diunggah dan PHP aktif.",
  DB_CONNECT: "Server tidak dapat terhubung ke database. Periksa isi api/config.php.",
  SERVER: "Terjadi kesalahan di server. Pastikan database.sql sudah diimpor.",
  INVALID_INPUT: "Data yang dimasukkan tidak valid." }[e.message] || "Terjadi kesalahan. Silakan coba lagi.");
const validEmail = e => /^\S+@\S+\.\S+$/.test(e.trim());

function setErr(id, msg) {
  const input = $(id), err = $("err-" + id);
  if (input) input.closest(".input-box").classList.toggle("invalid", !!msg);
  if (err) err.textContent = msg || "";
}
function setFormErr(id, msg) { const el = $(id); el.textContent = msg || ""; el.classList.toggle("hidden", !msg); }
function setBusy(btn, busy, text) { btn.disabled = busy; btn.textContent = busy ? "Memproses..." : text; }


document.querySelectorAll("[data-toggle]").forEach(b => b.addEventListener("click", () => {
  const i = $(b.dataset.toggle), show = i.type === "password";
  i.type = show ? "text" : "password"; b.textContent = show ? "Sembunyikan" : "Tampilkan";
}));


// ===== Aplikasi (dashboard) =====
const esc=t=>String(t).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const LET=[];
let SNAP={}; // surat terakhir yang sudah tersimpan di server (untuk mendeteksi perubahan)
const snapOf=l=>JSON.stringify(l);
async function loadLetters(){const j=await api("surat.php");LET.length=0;j.data.forEach(x=>LET.push(x));SNAP={};LET.forEach(l=>{SNAP[l.n]=snapOf(l);});}
// Dipanggil setiap kode lama memanggil saveLet(): kirim surat yang baru/berubah ke database
const saveLet=()=>{LET.forEach(l=>{const s=snapOf(l);if(SNAP[l.n]===s)return;SNAP[l.n]=s;api("surat.php",l).catch(e=>{delete SNAP[l.n];toast(e.message==="NETWORK"?"Tidak ada koneksi ke server. Perubahan belum tersimpan.":"Gagal menyimpan ke database.");});});};
// Dimuat sekali sebelum halaman tampil: akun yang login + semua surat dari database
const DB_READY=(async()=>{try{CURRENT=(await api("me.php")).user;if(CURRENT)await loadLetters();}catch(e){window.DB_ERROR=e.message;}})();
const NAV=[["dashboard","Dashboard","▦"],["cari","Pencarian","🔍"],["masuk","Surat masuk","✉"],["keluar","Surat keluar","➤"],["disposisi","Disposisi","⇅"],["arsip","Arsip surat","▣"],["cetak","Cetak surat","⎙"],0,["kontak","Kontak & Instansi","☎"],["laporan","Laporan","▤"],["pengaturan","Pengaturan","⚙"]];
const PILL={"Perlu disposisi":"w","Terkirim":"g","Diproses":"b","Diarsipkan":"n"};
const S={v:"dashboard",tab:"all",st:"all",q:""};
let me=null;
function toast(m){const e=document.createElement("div");e.className="toast";e.textContent=m;document.body.appendChild(e);setTimeout(()=>e.remove(),2200);}
const pick=f=>LET.filter(l=>f(l)&&(S.st==="all"||S.st===l.st)&&(!S.q||(l.n+l.p+l.a).toLowerCase().includes(S.q.toLowerCase())));
const tbl=l=>`<div class="tw"><table><thead><tr><th>Nomor surat</th><th>Perihal</th><th>Pengirim / Penerima</th><th>Tanggal</th><th>Status</th></tr></thead><tbody>${l.map(r=>`<tr class="cl" data-open="${esc(r.n)}"><td><b>${esc(r.n)}</b><small>${r.j==="masuk"?"Surat masuk":"Surat keluar"}</small></td><td>${esc(r.p)}</td><td><b>${esc(r.a)}</b><small>${esc(r.s)}</small></td><td>${r.t}</td><td><span class="pill ${PILL[r.st]}">${r.st}</span></td></tr>`).join("")||'<tr><td colspan="5" class="empty">${LET.length?"Tidak ada surat yang cocok.":"Belum ada surat. Klik + Tambah surat untuk memulai."}</td></tr>'}</tbody></table></div>`;
const stSel=()=>`<select id="stsel">${["all","Perlu disposisi","Diproses","Terkirim","Diarsipkan"].map(x=>`<option value="${x}"${S.st===x?" selected":""}>${x==="all"?"Semua status":x}</option>`).join("")}</select>`;
const head=(t,sub,btn=true)=>`<div class="head"><div><h2>${t}</h2><p>${sub}</p></div><div class="r">${btn?'<button class="bt" id="add">+ Tambah surat</button>':""}</div></div>`;
const listBox=(title,sub,l)=>`<div class="box"><div class="bh"><h3>${title}</h3><div class="r">${stSel()}</div></div><p style="margin:-6px 0 8px;font-size:12px;color:var(--muted)">${sub}</p>${tbl(l)}<p style="font-size:12px;color:var(--muted);margin:12px 0 0">Menampilkan ${l.length} surat</p></div>`;

const ini=n=>n.split(" ").map(w=>w[0]).slice(0,2).join("").toUpperCase();
