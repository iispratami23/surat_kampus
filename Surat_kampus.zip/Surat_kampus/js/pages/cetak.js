// Halaman Cetak surat: pratinjau + pengaturan cetak, dicetak lewat window.print().
// Isi dokumen mengikuti surat yang ada (nomor, perihal, pengirim/penerima, tanggal, disposisi).
(function () {
  const BULAN = { Jan: "Januari", Feb: "Februari", Mar: "Maret", Apr: "April", Mei: "Mei", Jun: "Juni", Jul: "Juli", Agu: "Agustus", Sep: "September", Okt: "Oktober", Nov: "November", Des: "Desember" };
  const SIZE = { A4: [210, 297], F4: [215, 330], Letter: [216, 279] };
  const SIZE_LABEL = { A4: "A4 (210 × 297 mm)", F4: "F4 / Folio (215 × 330 mm)", Letter: "Letter (216 × 279 mm)" };
  const MARGIN = { Normal: [18, 20], Sempit: [12, 12], Lebar: [25, 25] }; // [atas-bawah, kiri-kanan] dalam mm
  const KOP_KEY = "surat_kop";
  const DEFAULT_ISI = "Dengan hormat,\n\nSehubungan dengan perihal tersebut di atas, bersama ini kami sampaikan surat ini untuk ditindaklanjuti sebagaimana mestinya.\n\nDemikian surat ini kami sampaikan. Atas perhatian dan kerja sama Bapak/Ibu, kami ucapkan terima kasih.";
  const q = new URLSearchParams(location.search);
  const C = { n: q.get("n") || (LET[0] ? LET[0].n : ""), doc: "surat", dest: "printer", copies: 1, size: "A4", orient: "portrait", color: "color", margin: "Normal", zoom: 75 };

  const kopDef = () => ({ instansi: "Universitas Handayani Makasar", unit: "Administrasi umum", alamat: "", kota: "Makasar", ttd: me.nama, jabatan: me.jabatan || "Staf Administrasi" });
  const kop = () => { try { return Object.assign(kopDef(), JSON.parse(store.getItem(KOP_KEY)) || {}); } catch (e) { return kopDef(); } };
  const cur = () => LET.find((x) => x.n === C.n) || LET[0] || null;
  const pickDoc = () => { const r = cur(); if (r) C.doc = r.j === "masuk" ? "disposisi" : "surat"; };
  const tgl = (t) => { const m = String(t).match(/^(\d{1,2})\s+(\S+?)\.?\s+(\d{4})$/); return m && BULAN[m[2]] ? +m[1] + " " + BULAN[m[2]] + " " + m[3] : t; };
  const iso = (s) => { if (!s) return ""; const d = new Date(s); return isNaN(d) ? s : d.toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" }); };
  const dims = () => { const s = SIZE[C.size]; return C.orient === "landscape" ? [s[1], s[0]] : [s[0], s[1]]; };
  const para = (t) => esc(t).replace(/\n/g, "<br>");
  const inisial = (n) => n.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
  DB_READY.then(pickDoc);

  // ----- CSS halaman ini (disisipkan dari sini supaya style.css tidak berubah) -----
  const css = document.createElement("style");
  css.textContent = `
.cx{display:grid;grid-template-columns:minmax(0,1fr) 330px;gap:18px;align-items:start}
.pv,.cp{background:var(--card);border:1px solid var(--border);border-radius:12px}.pv{overflow:hidden}
.pvh{display:flex;align-items:center;gap:8px;padding:10px 14px;border-bottom:1px solid var(--border);font-size:13px;font-weight:600}
.pvh .r{margin-left:auto;display:flex;align-items:center;gap:6px;font-weight:400}
.pvb{background:var(--bg);padding:20px;overflow:auto;max-height:80vh}
.cp{padding:16px}.cp h3{margin:0 0 2px;font-size:16px}.cp .f{margin-top:14px}.cp label{font-size:13px;margin-bottom:6px}
.cp select,.cp input.t,.cp textarea{width:100%;border:1px solid var(--border);border-radius:8px;padding:8px 10px;font:inherit;font-size:13px;background:var(--card);color:var(--text)}
.cp summary{cursor:pointer;font-size:13px;font-weight:600;color:var(--navy)}
.seg{display:flex;gap:6px;align-items:center}.seg button{flex:1;border:1px solid var(--border);background:var(--card);color:var(--text);padding:8px;border-radius:8px;font:inherit;font-size:13px;cursor:pointer}
.seg button.on{border-color:var(--acc);background:var(--accbg);color:var(--acc);font-weight:600}
.sum{background:var(--bg);border-radius:10px;padding:12px;font-size:12px;color:var(--muted);margin-top:14px;line-height:1.6}
.sheet{background:#fff;color:#111;font-family:"Times New Roman",Times,serif;font-size:12pt;line-height:1.5;box-shadow:0 1px 8px rgba(0,0,0,.18);margin:0 auto;box-sizing:border-box;overflow:hidden;text-align:left}
.kop{display:flex;gap:12px;align-items:center;border-bottom:2px solid #2F6B4F;padding-bottom:8px;margin-bottom:14px}
.lg{width:46px;height:46px;border-radius:8px;background:#2F6B4F;color:#fff;display:grid;place-items:center;font:700 16pt Arial,sans-serif;flex:none}
.ki{font:700 14pt Arial,sans-serif;color:#2F6B4F}.ku{font:700 8pt Arial,sans-serif}.ka{font:8pt Arial,sans-serif;color:#444}
.tr{text-align:right;margin-bottom:8px}.info{border-collapse:collapse;margin:0 0 10px}.info td{padding:0 6px 0 0;vertical-align:top}
.grid{width:100%;border-collapse:collapse;margin:10px 0}.grid th,.grid td{border:1px solid #333;padding:5px 6px;font-size:10.5pt;text-align:left;height:26px;vertical-align:top}
.jd{text-align:center;margin:6px 0 12px;font-size:13pt;letter-spacing:.05em}
.ttd{margin:24px 0 0 auto;width:55%}.ttd .sp{height:62px}
.bw{filter:grayscale(1)}#printarea{display:none}
@media print{
 .side,.top,.pagehead,.head,.cx{display:none!important}
 .shell,.wrap{display:block!important}body.app{background:#fff!important;display:block}main#main{padding:0;max-width:none}
 #printarea{display:block}
 .sheet{box-shadow:none;padding:0!important;width:auto!important;min-height:0!important;page-break-after:always;overflow:visible}
 .sheet:last-child{page-break-after:auto}
}
@media(max-width:1000px){.cx{grid-template-columns:1fr}}`;
  document.head.appendChild(css);
  const pg = document.createElement("style"); pg.id = "pgstyle"; document.head.appendChild(pg);
  const pageCss = () => { const d = dims(), m = MARGIN[C.margin];
    return `@page{size:${d[0]}mm ${d[1]}mm;margin:${m[0]}mm ${m[1]}mm}.sheet{width:${d[0]}mm;min-height:${d[1]}mm;padding:${m[0]}mm ${m[1]}mm}`; };

  // ----- Isi dokumen -----
  const kopHtml = (k) => `<div class="kop"><div class="lg">${esc(inisial(k.instansi))}</div><div><div class="ki">${esc(k.instansi)}</div><div class="ku">${esc(k.unit.toUpperCase())}</div>${k.alamat ? `<div class="ka">${esc(k.alamat)}</div>` : ""}</div></div>`;
  const ttdHtml = (k, sapa) => `<div class="ttd"><div>${sapa}</div><div>${esc(k.unit)} ${esc(k.instansi)}</div><div class="sp"></div><b><u>${esc(k.ttd)}</u></b><div>${esc(k.jabatan)}</div></div>`;
  function sheetHtml(r) {
    const k = kop();
    if (C.doc === "disposisi") {
      const hist = (r.disp || []).slice().reverse();
      const rows = hist.map((h, i) => `<tr><td>${i + 1}</td><td>${esc(h.ke)}</td><td>${esc(h.instruksi)}</td><td>${esc(iso(h.batas))}</td><td>${esc(h.catatan || "")}</td><td>${esc(h.t)}</td></tr>`);
      while (rows.length < 4) rows.push(`<tr><td>${rows.length + 1}</td><td></td><td></td><td></td><td></td><td></td></tr>`);
      return `<section class="sheet">${kopHtml(k)}<h3 class="jd">LEMBAR DISPOSISI</h3>
        <table class="info"><tr><td>Nomor surat</td><td>: ${esc(r.n)}</td></tr><tr><td>Tanggal surat</td><td>: ${esc(tgl(r.t))}</td></tr>
        <tr><td>Jenis surat</td><td>: ${r.j === "masuk" ? "Surat masuk" : "Surat keluar"}</td></tr><tr><td>${r.j === "masuk" ? "Pengirim" : "Penerima"}</td><td>: ${esc(r.a)}</td></tr>
        <tr><td>Perihal</td><td>: ${esc(r.p)}</td></tr><tr><td>Status</td><td>: ${esc(r.st)}</td></tr></table>
        <table class="grid"><tr><th>No</th><th>Diteruskan kepada</th><th>Instruksi</th><th>Batas waktu</th><th>Catatan</th><th>Tanggal</th></tr>${rows.join("")}</table>
        ${ttdHtml(k, "Mengetahui,")}</section>`;
    }
    return `<section class="sheet">${kopHtml(k)}<div class="tr">${esc(k.kota)}, ${esc(tgl(r.t))}</div>
      <table class="info"><tr><td>Nomor</td><td>: ${esc(r.n)}</td></tr><tr><td>Lampiran</td><td>: ${esc(r.lampiran || "-")}</td></tr><tr><td>Perihal</td><td>: ${esc(r.p)}</td></tr></table>
      <p style="margin:0 0 12px">Yth. ${esc(r.a)}<br>di tempat</p><div>${para(r.isi || DEFAULT_ISI)}</div>${ttdHtml(k, "Hormat kami,")}</section>`;
  }

  // ----- Tampilan halaman -----
  const summary = () => `${C.doc === "disposisi" ? "Lembar disposisi" : "Surat"} · ${C.copies} salinan · ${C.size} · ${C.orient === "portrait" ? "Potret" : "Lanskap"} · ${C.color === "color" ? "Berwarna" : "Hitam putih"} · Margin ${C.margin}`;
  const seg = (key, items) => `<div class="seg">${items.map((i) => `<button type="button" data-c="${key}:${i[0]}" class="${C[key] === i[0] ? "on" : ""}">${i[1]}</button>`).join("")}</div>`;
  const sel = (id, obj, val) => `<select id="${id}">${Object.keys(obj).map((x) => `<option value="${x}"${x === val ? " selected" : ""}>${esc(typeof obj[x] === "string" ? obj[x] : x)}</option>`).join("")}</select>`;

  startPage("cetak", function () {
    const r = cur();
    if (!r) return `<div class="head"><div><h2>Cetak surat</h2><p>Belum ada surat yang bisa dicetak. Tambahkan surat dulu di menu Surat masuk atau Surat keluar.</p></div><div class="r"><button class="bt" data-nav="masuk">Ke Surat masuk</button></div></div>`;
    C.n = r.n; const k = kop();
    pg.textContent = pageCss();
    const kf = [["instansi", "Nama instansi"], ["unit", "Unit / bagian"], ["alamat", "Alamat (opsional)"], ["kota", "Kota penerbitan"], ["ttd", "Nama penandatangan"], ["jabatan", "Jabatan penandatangan"]];
    return `<div class="pagehead"><button class="bs" data-nav="dashboard">← Kembali ke dashboard</button></div>
    <div class="head" style="margin-top:14px"><div><h2>Cetak surat</h2><p id="sub">${esc(r.p)} / ${esc(r.n)}</p></div></div>
    <div class="cx"><div class="pv"><div class="pvh">Pratinjau dokumen<div class="r"><button class="bs" data-c="zoom:-10">−</button><span id="zv">${C.zoom}%</span><button class="bs" data-c="zoom:10">+</button></div></div>
      <div class="pvb"><div id="paperwrap" class="${C.color === "bw" ? "bw" : ""}" style="zoom:${C.zoom / 100}"><div id="paper">${sheetHtml(r)}</div></div></div></div>
    <div class="cp"><h3>Pengaturan cetak</h3><p style="margin:0;font-size:12px;color:var(--muted)">Sesuaikan hasil cetak dokumen Anda.</p>
      <div class="f"><label>Surat</label><select id="c-letter">${LET.map((x) => `<option value="${esc(x.n)}"${x.n === r.n ? " selected" : ""}>${esc(x.n)} · ${esc(x.p.slice(0, 38))}</option>`).join("")}</select></div>
      <div class="f"><label>Jenis dokumen</label>${seg("doc", [["surat", "Surat"], ["disposisi", "Lembar disposisi"]])}</div>
      <div class="f"><label>Tujuan</label>${seg("dest", [["printer", "Printer"], ["pdf", "Simpan PDF"]])}</div>
      <div class="f"><label>Jumlah salinan</label><div class="seg"><button type="button" data-c="copies:-1">−</button><b style="min-width:44px;text-align:center">${C.copies}</b><button type="button" data-c="copies:1">+</button></div></div>
      <div class="f"><label>Ukuran kertas</label>${sel("c-size", SIZE_LABEL, C.size)}</div>
      <div class="f"><label>Orientasi</label>${seg("orient", [["portrait", "Potret"], ["landscape", "Lanskap"]])}</div>
      <div class="f"><label>Margin</label>${sel("c-margin", MARGIN, C.margin)}</div>
      <div class="f"><label>Mode warna</label>${sel("c-color", { color: "Berwarna", bw: "Hitam putih" }, C.color)}</div>
      ${C.doc === "surat" ? `<div class="f"><label>Lampiran</label><input class="t" id="c-lamp" value="${esc(r.lampiran || "")}" placeholder="Contoh: 1 berkas"><label style="margin-top:10px">Isi surat</label><textarea id="c-isi" rows="8">${esc(r.isi || DEFAULT_ISI)}</textarea></div>` : ""}
      <details class="f"><summary>Kop dan penandatangan</summary>${kf.map((f) => `<div class="f"><label>${f[1]}</label><input class="t" data-kop="${f[0]}" value="${esc(k[f[0]] || "")}"></div>`).join("")}</details>
      <div class="sum" id="sum">${summary()}</div>
      <button class="bt" id="c-print" style="width:100%;margin-top:14px">${C.dest === "pdf" ? "Simpan sebagai PDF" : "Cetak"}</button></div></div>
    <div id="printarea"></div>`;
  });

  function updatePreview() {
    const r = cur(); if (!r || !document.getElementById("paper")) return;
    pg.textContent = pageCss();
    document.getElementById("paper").innerHTML = sheetHtml(r);
    document.getElementById("sum").textContent = summary();
  }
  function fillPrint() {
    const r = cur(), a = document.getElementById("printarea"); if (!r || !a) return;
    pg.textContent = pageCss(); a.className = C.color === "bw" ? "bw" : "";
    a.innerHTML = Array.from({ length: C.copies }, () => sheetHtml(r)).join("");
  }
  window.addEventListener("beforeprint", fillPrint);

  // ----- Interaksi -----
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-c]");
    if (b) {
      const p = b.dataset.c.split(":"), key = p[0], val = p[1];
      if (key === "copies") C.copies = Math.min(20, Math.max(1, C.copies + Number(val)));
      else if (key === "zoom") { C.zoom = Math.min(150, Math.max(30, C.zoom + Number(val))); const w = document.getElementById("paperwrap"); w.style.zoom = C.zoom / 100; document.getElementById("zv").textContent = C.zoom + "%"; return; }
      else C[key] = val;
      draw(); return;
    }
    if (e.target.closest("#c-print")) {
      if (C.dest === "pdf") toast('Di jendela cetak, pilih "Simpan sebagai PDF" pada kolom Printer.');
      fillPrint();
      try { window.print(); } catch (err) { toast("Cetak tidak tersedia di tampilan ini. Buka aplikasi di browser."); }
    }
  });
  document.addEventListener("change", (e) => {
    const id = e.target.id, v = e.target.value;
    if (id === "c-letter") { C.n = v; pickDoc(); draw(); }
    else if (id === "c-size") { C.size = v; draw(); }
    else if (id === "c-margin") { C.margin = v; draw(); }
    else if (id === "c-color") { C.color = v; draw(); }
  });
  document.addEventListener("input", (e) => {
    const t = e.target;
    if (t.dataset && t.dataset.kop) { const k = kop(); k[t.dataset.kop] = t.value; store.setItem(KOP_KEY, JSON.stringify(k)); updatePreview(); }
    else if (t.id === "c-lamp" || t.id === "c-isi") { const r = cur(); if (!r) return; r[t.id === "c-lamp" ? "lampiran" : "isi"] = t.value; saveLet(); updatePreview(); }
  });
})();
