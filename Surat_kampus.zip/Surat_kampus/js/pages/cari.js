// Halaman Pencarian: cari surat berdasarkan nomor, perihal, pengirim/penerima, tanggal, status, atau isi.
(function () {
  const Q = { q: new URLSearchParams(location.search).get("q") || "", j: "all", st: "all" };
  const css = document.createElement("style");
  css.textContent = "a.bs{text-decoration:none;display:inline-block}.res{padding:14px;margin-bottom:10px}.res:hover{border-color:var(--acc)}.res .top2{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:6px}.res .r{margin-left:auto}";
  document.head.appendChild(css);

  function results() {
    const ws = cariWords(Q.q), list = cariSurat(Q.q, { j: Q.j, st: Q.st });
    if (!LET.length) return '<div class="box empty">Belum ada surat tercatat. Tambahkan lewat menu Surat masuk atau Surat keluar.</div>';
    const info = `<p style="margin:0 0 12px;font-size:13px;color:var(--muted)">${ws.length ? `Ditemukan <b>${list.length}</b> surat untuk “${esc(Q.q.trim())}”` : `Menampilkan semua surat (<b>${list.length}</b>). Ketik kata kunci untuk mempersempit.`}</p>`;
    if (!list.length) return info + '<div class="box empty">Tidak ada surat yang cocok. Coba kata kunci lain, atau ubah filter jenis dan status.</div>';
    return info + list.map((r) => {
      const vis = [r.n, r.p, r.a, r.s, r.t, r.st].join(" ").toLowerCase();
      const hid = [r.isi, (r.disp || []).map((d) => [d.ke, d.instruksi, d.catatan].join(" ")).join(" ")].join(" ").toLowerCase();
      const hint = ws.some((w) => !vis.includes(w) && hid.includes(w)) ? " · cocok di isi surat atau disposisi" : "";
      return `<div class="box res"><div data-open="${esc(r.n)}" style="cursor:pointer">
        <div class="top2"><span class="pill ${r.j === "masuk" ? "b" : "g"}">${r.j === "masuk" ? "Surat masuk" : "Surat keluar"}</span><b>${cariHighlight(r.n, ws)}</b><span class="pill ${PILL[r.st]} r">${esc(r.st)}</span></div>
        <div style="font-size:14px">${cariHighlight(r.p, ws)}</div>
        <small style="color:var(--muted)">${cariHighlight(r.a, ws)} · ${esc(r.t)}${hint}</small></div>
        <div style="margin-top:10px"><a class="bs" href="cetak.html?n=${encodeURIComponent(r.n)}">Cetak</a></div></div>`;
    }).join("");
  }

  startPage("cari", function () {
    setTimeout(() => { const i = document.getElementById("cq"); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }, 0);
    return head("Pencarian", "Cari surat berdasarkan nomor, perihal, pengirim/penerima, tanggal, status, atau isi.", false) +
      `<div class="box"><div class="input-box"><span style="color:var(--muted)">🔍</span><input id="cq" value="${esc(Q.q)}" placeholder="Ketik nomor surat, perihal, atau nama pengirim..." style="padding-left:10px" autocomplete="off"></div>
      <div class="bh" style="margin:14px 0 0"><div class="tabs">${[["all", "Semua"], ["masuk", "Surat masuk"], ["keluar", "Surat keluar"]].map((t) => `<button data-cj="${t[0]}" class="${Q.j === t[0] ? "on" : ""}">${t[1]}</button>`).join("")}</div>
      <div class="r"><select id="cst">${["all", "Perlu disposisi", "Diproses", "Terkirim", "Diarsipkan"].map((x) => `<option value="${x}"${Q.st === x ? " selected" : ""}>${x === "all" ? "Semua status" : x}</option>`).join("")}</select></div></div></div>
      <div id="results">${results()}</div>`;
  });

  document.addEventListener("input", (e) => {
    if (e.target.id === "cq") {
      Q.q = e.target.value; document.getElementById("results").innerHTML = results();
      try { history.replaceState(null, "", "cari.html" + (Q.q.trim() ? "?q=" + encodeURIComponent(Q.q.trim()) : "")); } catch (err) {}
    } else if (e.target.id === "q") { Q.q = e.target.value; draw(); } // kolom cari di atas ikut mencari
  });
  document.addEventListener("click", (e) => { const b = e.target.closest("[data-cj]"); if (b) { Q.j = b.dataset.cj; draw(); } });
  document.addEventListener("change", (e) => { if (e.target.id === "cst") { Q.st = e.target.value; draw(); } });
})();
