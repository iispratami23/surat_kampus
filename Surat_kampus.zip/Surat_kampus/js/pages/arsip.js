// Halaman Arsip surat
startPage("arsip", ()=>head("Arsip surat","Dokumen yang sudah selesai diproses.")+listBox("Surat diarsipkan","Surat dengan status Diarsipkan.",pick(x=>x.st==="Diarsipkan")));
