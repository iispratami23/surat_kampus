// Halaman Disposisi
startPage("disposisi", ()=>head("Disposisi","Surat yang menunggu arahan atau tindak lanjut.")+listBox("Perlu disposisi","Surat dengan status Perlu disposisi.",pick(x=>x.st==="Perlu disposisi")));
