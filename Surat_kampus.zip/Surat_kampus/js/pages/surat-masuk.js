// Halaman Surat masuk
startPage("masuk", ()=>head("Surat masuk","Semua surat yang diterima organisasi.")+listBox("Daftar surat masuk","Klik baris untuk melihat ringkasan.",pick(x=>x.j==="masuk")));
