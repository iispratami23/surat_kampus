// Halaman Surat keluar
startPage("keluar", ()=>head("Surat keluar","Semua surat yang dikirim organisasi.")+listBox("Daftar surat keluar","Klik baris untuk melihat ringkasan.",pick(x=>x.j==="keluar")));
