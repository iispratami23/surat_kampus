// register.js: logika halaman daftar
// Jika sudah login, langsung ke dashboard
DB_READY.then(() => {
  if (currentUser()) location.replace("dashboard.html");
  else if (window.DB_ERROR) setFormErr("reg-form-error", errMsg(new Error(window.DB_ERROR)));
});

$("register-form").addEventListener("submit", async e => {
  e.preventDefault();
  const d = { nama: $("reg-nama").value.trim(), jabatan: $("reg-jabatan").value.trim(), email: $("reg-email").value.trim(), password: $("reg-password").value };
  const konf = $("reg-konfirmasi").value;
  const errs = {
    "reg-nama": d.nama ? "" : "Nama lengkap wajib diisi.",
    "reg-email": validEmail(d.email) ? "" : "Masukkan email yang valid.",
    "reg-password": d.password.length >= 6 ? "" : "Kata sandi minimal 6 karakter.",
    "reg-konfirmasi": konf === d.password ? "" : "Konfirmasi kata sandi tidak sama."
  };
  setFormErr("reg-form-error", ""); Object.keys(errs).forEach(k => setErr(k, errs[k]));
  if (Object.values(errs).some(Boolean)) return;
  try { setBusy($("reg-btn"), true, "Daftar"); await registerUser(d); location.href = "dashboard.html"; }
  catch (err) { setFormErr("reg-form-error", errMsg(err)); }
  finally { setBusy($("reg-btn"), false, "Daftar"); }
});


