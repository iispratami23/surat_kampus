// layout.js: kerangka dashboard (sidebar, topbar), dialog tambah surat, dan event bersama
const PAGE={dashboard:"dashboard.html",cari:"cari.html",masuk:"surat-masuk.html",keluar:"surat-keluar.html",disposisi:"disposisi.html",arsip:"arsip.html",cetak:"cetak.html",kontak:"kontak.html",laporan:"laporan.html",pengaturan:"pengaturan.html"};
let VIEW=null;

function shell(user){
  return `<div class="shell"><aside class="side"><div class="logo">akun.</div><div class="org"><b>Universitas Handayani Makasar</b><small>Administrasi umum</small></div><div class="sec">RUANG KERJA</div>${NAV.map(n=>n?`<a class="nav${n[0]===S.v?" on":""}" href="${PAGE[n[0]]}"><span>${n[2]}</span>${n[1]}${n[3]?`<i class="bd" style="font-style:normal">${n[3]}</i>`:""}</a>`:'<div class="sec">PENGELOLAAN</div>').join("")}<div class="help"><b>Butuh bantuan?</b>Temukan panduan pengelolaan surat Anda.</div><button class="nav" id="logout-btn"><span>⇥</span>Keluar</button></aside><div class="wrap"><div class="top"><div class="crumb">Ruang kerja › <b>${NAV.filter(Boolean).find(n=>n[0]===S.v)[1]}</b></div><input class="search" id="q" placeholder="Cari surat, nomor, atau perihal..."><button class="icb" data-toast="Tidak ada notifikasi baru." aria-label="Notifikasi">🔔</button><div class="me"><span class="av">${esc(ini(user.nama))}</span><div>${esc(user.nama)}<small>${user.role==="admin"?"Administrator":"Staf"}</small></div></div></div><main id="main"></main></div></div>`;
}

// Dipanggil oleh setiap halaman: startPage("kunci-menu", fungsiTampilan)
function startPage(key,view){
  DB_READY.then(()=>startPageNow(key,view));
}
function startPageNow(key,view){
  me=currentUser();
  if(!me){location.replace("login.html");return;}
  const th=store.getItem("surat_theme"); if(th) document.documentElement.dataset.theme=th;
  S.v=key; VIEW=view;
  $("app").innerHTML=shell(me);
  draw();
}
function draw(){
  $("main").innerHTML=VIEW();
  const t=$("theme"); if(t) t.value=document.documentElement.dataset.theme||"";
}
function openAdd(){const d=$("dlg");d.innerHTML=`<form method="dialog" id="addf"><h3 style="margin:0 0 14px;color:var(--navy)">Tambah surat</h3><div class="field"><label>Jenis</label><select id="aj" style="width:100%"><option value="masuk">Surat masuk</option><option value="keluar">Surat keluar</option></select></div><div class="field"><label>Nomor surat</label><div class="input-box"><input id="an" required></div></div><div class="field"><label>Perihal</label><div class="input-box"><input id="ap" required></div></div><div class="field"><label>Pengirim / penerima</label><div class="input-box"><input id="aa" required></div></div><button class="bt" style="width:100%">Simpan surat</button> <button type="button" class="bs" style="width:100%;margin-top:8px" id="acx">Batal</button></form>`;d.showModal();}

document.addEventListener("click",e=>{
  const t=e.target, c=x=>t.closest(x);
  if(c("#logout-btn")){logoutUser().then(()=>{location.href="login.html";});}
  else if(c("[data-nav]")){location.href=PAGE[c("[data-nav]").dataset.nav];}
  else if(c("[data-tab]")){S.tab=c("[data-tab]").dataset.tab;draw();}
  else if(c("[data-toast]")){toast(c("[data-toast]").dataset.toast);}
  else if(c("[data-open]")){const r=LET.find(x=>x.n===c("[data-open]").dataset.open);toast(r.p+" — "+r.st);}
  else if(c("#add")){openAdd();}
  else if(c("#acx")){$("dlg").close();}
});
document.addEventListener("change",e=>{
  if(e.target.id==="stsel"){S.st=e.target.value;draw();}
  if(e.target.id==="theme"){
    if(e.target.value){document.documentElement.dataset.theme=e.target.value;store.setItem("surat_theme",e.target.value);}
    else{delete document.documentElement.dataset.theme;store.removeItem("surat_theme");}
  }
});
document.addEventListener("input",e=>{if(e.target.id==="q"){S.q=e.target.value;draw();}});
document.addEventListener("submit",e=>{
  if(e.target.id!=="addf")return;
  const d=new Date().toLocaleDateString("id-ID",{day:"2-digit",month:"short",year:"numeric"});
  LET.unshift({n:$("an").value.trim(),j:$("aj").value,p:$("ap").value.trim(),a:$("aa").value.trim(),s:"Internal · Universitas Handayani Makasar",t:d,st:"Diproses"});
  saveLet(); draw(); toast("Surat berhasil ditambahkan.");
});
